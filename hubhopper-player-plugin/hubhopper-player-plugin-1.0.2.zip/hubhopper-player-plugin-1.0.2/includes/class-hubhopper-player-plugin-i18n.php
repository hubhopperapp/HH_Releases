<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       hubhopper.com
 * @since      1.0.0
 *
 * @package    Hubhopper_Player_Plugin
 * @subpackage Hubhopper_Player_Plugin/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Hubhopper_Player_Plugin
 * @subpackage Hubhopper_Player_Plugin/includes
 * @author     Hubhopper <support@hubhopper.com>
 */
class Hubhopper_Player_Plugin_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'hh-player-plugin',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
