<?php

/**
 * Fired during plugin activation
 *
 * @link       hubhopper.com
 * @since      1.0.0
 *
 * @package    Hubhopper_Player_Plugin
 * @subpackage Hubhopper_Player_Plugin/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Hubhopper_Player_Plugin
 * @subpackage Hubhopper_Player_Plugin/includes
 * @author     Hubhopper <support@hubhopper.com>
 */
class Hubhopper_Player_Plugin_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
