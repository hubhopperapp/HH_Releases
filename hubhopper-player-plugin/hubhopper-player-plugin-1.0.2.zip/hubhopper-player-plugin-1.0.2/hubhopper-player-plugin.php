<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              hubhopper.com
 * @since             1.0.2
 * @package           Hubhopper_Player_Plugin
 *
 * @wordpress-plugin
 * Plugin Name:       Hubhopper Player Plugin
 * Plugin URI:        embed.hubhopper.com/plugin
 * Description:       This plugin let's you configure the Hubhopper Podcast Playing capabilities in your wordpress. Now let everyone hear what you love.
 * Version:           1.0.2
 * Author:            Hubhopper
 * Author URI:        hubhopper.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       hh-player-plugin
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'PLUGIN_NAME_VERSION', '1.0.2' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-hubhopper-player-plugin-activator.php
 */
function activate_hubhopper_player_plugin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-hubhopper-player-plugin-activator.php';
	Hubhopper_Player_Plugin_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-hubhopper-player-plugin-deactivator.php
 */
function deactivate_hubhopper_player_plugin() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-hubhopper-player-plugin-deactivator.php';
	Hubhopper_Player_Plugin_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_hubhopper_player_plugin' );
register_deactivation_hook( __FILE__, 'deactivate_hubhopper_player_plugin' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-hubhopper-player-plugin.php';

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ) , 'add_settings_link' );

function add_settings_link ( $links ) {
	$mylinks = array('<a href="' . esc_url ( admin_url( 'admin.php?page=hh-player-settings' ) ) . '">Settings</a>',);
	return array_merge( $links, $mylinks );
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_hubhopper_player_plugin() {

	$plugin = new Hubhopper_Player_Plugin();
	$plugin->run();

}
run_hubhopper_player_plugin();
