(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	$.fn.serializeObject = function()
	{
	    var o = {};
	    var a = this.serializeArray();
	    $.each(a, function() {
	        if (this.name !== 'data' || this.name !== 'hh_player_wnonce' || this.name !== '_wp_http_referer') {
				if (o[this.name] !== undefined) {
		            if (!o[this.name].push) {
		                o[this.name] = [o[this.name]];
		            }
		            o[this.name].push(this.value || '');
		        } else {
		            o[this.name] = this.value || '';
		        }
	        }
	    });
	    return o;
	};

	$(function() {
		//'brYtLh1a454ioSNEQ7fOe3Q8OUTTfhaV9q7lyunm'
		var key = $( '#apiKey' ).val();
		
		$( "#podcastSearch" ).focus(function() {
			key = $( '#apiKey' ).val();
			if(! key.trim()) {
				alert('Please enter API Key to continue');
				$( "#apiKey" ).focus();
			}
			else {
				$( "#podcastSearch" ).autocomplete({
		      		source: function( request, response ) {
		        		$.ajax( {
		          			url: "https://nwb3zg07k1.execute-api.ap-south-1.amazonaws.com/v4/search",
		          			dataType: 'json',
		          			headers: {
						        'X-Api-Key': key
						    },
		          			type: "get",
		          			data: {
		            			q: request.term,
		            			t: 'podcast'
		          			},
		          			success: function( data ) {
		            			response( data.response.podcasts.items );
		          			}
		        		} );
		      		},
		      		minLength: 3,
		      		select: function( event, ui ) {
		      			$( '#podcast' ).val(ui.item.podcast_id).data('item', ui.item);
		      			$( '#podcastDisplay' ).val(ui.item.title);
		      			//console.log( "Selected: " + ui.item.title + " aka " + ui.item.podcast_id );
		      		}
	    		}).autocomplete( "instance" )._renderItem = function( ul, item ) {
			      //console.log(item);
			      return $( "<li/>" )
			      		.append( "<div>" + item.title + "</div>" )
			      		.appendTo( ul );
			    };
			}
		});

		$( "#similarSearch" ).focus(function() {
			key = $( '#apiKey' ).val();
			if(! key.trim()) {
				alert('Please enter API Key to continue');
				$( "#apiKey" ).focus();
			}
			else {
				$( "#similarSearch" ).autocomplete({
		      		source: function( request, response ) {
		        		$.ajax( {
		          			url: "https://nwb3zg07k1.execute-api.ap-south-1.amazonaws.com/v4/search",
		          			dataType: 'json',
		          			headers: {
						        'X-Api-Key': key
						    },
		          			type: "get",
		          			data: {
		            			q: request.term,
		            			t: 'podcast'
		          			},
		          			success: function( data ) {
		            			response( data.response.podcasts.items );
		          			}
		        		} );
		      		},
		      		minLength: 3,
		      		select: function( event, ui ) {
		      			var curVal = $( '#similar' ).val();
		      			var curDis = $( '#similarDisplay' ).val();
		      			$( '#similar' ).val(!curVal ? ui.item.podcast_id : curVal + ", " + ui.item.podcast_id);
		      			$( '#similarDisplay' ).val(!curDis ? ui.item.title : curDis + ", " + ui.item.title);
		      			//console.log( "Selected: " + ui.item.title + " aka " + ui.item.podcast_id );
		      		}
	    		}).autocomplete( "instance" )._renderItem = function( ul, item ) {
			      //console.log(item);
			      return $( "<li/>" )
			      		.append( "<div>" + item.title + "</div>" )
			      		.appendTo( ul );
			    };
			}
		});

		$( '#similarClear' ).click(function() {
			$( '#selectedSimilar' ).val('');
		    $( '#similarDisplay' ).val('');
		});

		$( '#hhPlayerSettingForm' ).submit(function (e) {
			//e.preventDefault();
			$( '#formDataJson' ).val(JSON.stringify($('#hhPlayerSettingForm').serializeObject()));
		});

		$( '#cancel' ).click(function() {
			$(this).closest('form').find("input[type=text]").val("");
		});

    } );

})( jQuery );
