<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       hubhopper.com
 * @since      1.0.0
 *
 * @package    Hubhopper_Player_Plugin
 * @subpackage Hubhopper_Player_Plugin/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Hubhopper_Player_Plugin
 * @subpackage Hubhopper_Player_Plugin/public
 * @author     Hubhopper <support@hubhopper.com>
 */
class Hubhopper_Player_Plugin_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Hubhopper_Player_Plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Hubhopper_Player_Plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/hubhopper-player-plugin-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Hubhopper_Player_Plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Hubhopper_Player_Plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/hubhopper-player-plugin-public.js', array( 'jquery' ), $this->version, true );

		wp_enqueue_script( $this->plugin_name + '-player', '//embed.hubhopper.com/hhplayer.min.js', false);
		//wp_enqueue_script( $this->plugin_name + '-player', '//embed.hubhopper.com/hh.embed.js', false);

	}

	public function hhplayer_shortcodes() {

		add_shortcode( 'hhplayer', array( $this, 'shortcode_player') );

	}

	public function shortcode_player($atts) {

		$ats = shortcode_atts( array(
	        'type' => 'widget'
	    ), $atts );

		$hh_opts = json_decode(get_option('hh_player_setting_option'), true);
		$params = get_option('hh_player_options');

		//print_r($hh_opts);

		include( plugin_dir_path( dirname( __FILE__ ) ) . '/public/partials/hubhopper-player-plugin-public-display.php' );
	}

}
