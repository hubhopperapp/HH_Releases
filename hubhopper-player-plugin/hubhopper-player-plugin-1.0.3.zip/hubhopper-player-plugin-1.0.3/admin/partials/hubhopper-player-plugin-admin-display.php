<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       hubhopper.com
 * @since      1.0.0
 *
 * @package    Hubhopper_Player_Plugin
 * @subpackage Hubhopper_Player_Plugin/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">
 
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
 	<?php
 	$vals = $opts;
 	//print_r(json_encode($vals));
 	echo "<br />";

 	if($success) {
 	?>
 		<div class="notice notice-success is-dismissible"> 
			<p><strong>Settings saved. Use shortcode [hhplayer type="<?= $vals['widget'] ? 'widget' : 'in-page'?>"]</strong></p>
			<button type="button" class="notice-dismiss">
				<span class="screen-reader-text">Dismiss this notice.</span>
			</button>
		</div>
 	<?php
 	}
 	?>
    <form method="post" id="hhPlayerSettingForm">
    	
    	<div class="ui-widget">
			<label for="apiKey">Enter API KEY: </label>
			<input id="apiKey" name="apiKey" value="<?= $vals['apiKey'] ?>" />
		</div>
		<div class="ui-widget">
			<label for="containerId">Enter Plugin Display Id: </label>
			<input id="containerId" name="containerId" value="<?= $vals['containerId'] ?>" readonly />
		</div>

		<div class="ui-widget">
			<label for="podcastSearch">Select Podcast: </label>
			<input id="podcastSearch" />
			<input id="podcastDisplay" name="podcastDisplay" value="<?= $vals['podcastDisplay'] ?>" />
			<input id="podcast" name="podcast" type="hidden" value="<?= $vals['podcast']=== 0 ? '' : $vals['podcast'] ?>" />
		</div>
		<div class="ui-widget">
			<label for="similarSearch">Select Similar Podcasts: </label>
			<input id="similarSearch" />
			<input id="similarDisplay" name="similarDisplay" value="<?= $vals['similarDisplay'] ?>" />
			<input id="similar" name="similar" type="hidden" value="<?= $vals['similar'][0] === 0 ? '' : implode(',', $vals['similar']) ?>" />
			<input id="similarClear" type="button" value="Clear" />
		</div>
		<div class="ui-widget">
			<label for="externalizeSimilar">Open Similar Podcasts in a new tab: </label>
			<input id="externalizeSimilar" name="externalizeSimilar" type="radio" value="true" <?= $vals['externalizeSimilar'] ? 'checked="checked"' : '' ?> /> Yes
			<input id="externalizeSimilar" name="externalizeSimilar" type="radio" value="false" <?= $vals['externalizeSimilar'] ? '' : 'checked="checked"' ?> /> No
		</div>
		<div class="ui-widget">
			<label for="showSimilar">Show Similar Podcasts: </label>
			<input id="showSimilar" name="showSimilar" type="radio" value="true" <?= $vals['showSimilar'] ? 'checked="checked"' : '' ?> /> Yes
			<input id="showSimilar" name="showSimilar" type="radio" value="false" <?= $vals['showSimilar'] ? '' : 'checked="checked"' ?> /> No
		</div>
		<div class="ui-widget">
			<label for="autoPlay">Auto Play Selected Podcast: </label>
			<input id="autoPlay" name="autoPlay" type="radio" value="true" <?= $vals['autoPlay'] ? 'checked="checked"' : '' ?> /> Yes
			<input id="autoPlay" name="autoPlay" type="radio" value="false" <?= $vals['autoPlay'] ? '' : 'checked="checked"' ?> /> No
		</div>
		<div class="ui-widget">
			<label for="widget">Widget Mode: </label>
			<input id="widget" name="widget" type="radio" value="true" <?= $vals['widget'] ? 'checked="checked"' : '' ?> /> Yes
			<input id="widget" name="widget" type="radio" value="false" <?= $vals['widget'] ? '' : 'checked="checked"' ?> /> No
		</div>
		<div class="ui-widget">
			<input type="submit" value="Save" class="button button-primary button-large" />
			<input type="button" value="Cancel" class="button button-large" id="cancel" />
			<input id="formDataJson" name="data" type="hidden" value="" />
			<?php
			wp_nonce_field( $filename, 'hh_player_wnonce' );
			?>
		</div>
    </form>
 
</div><!-- .wrap -->