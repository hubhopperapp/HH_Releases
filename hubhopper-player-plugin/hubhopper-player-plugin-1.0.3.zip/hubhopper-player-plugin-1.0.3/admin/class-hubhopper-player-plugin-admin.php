<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       hubhopper.com
 * @since      1.0.0
 *
 * @package    Hubhopper_Player_Plugin
 * @subpackage Hubhopper_Player_Plugin/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Hubhopper_Player_Plugin
 * @subpackage Hubhopper_Player_Plugin/admin
 * @author     Hubhopper <support@hubhopper.com>
 */

if ( !function_exists( 'update_option' ) ) { 
    require_once ABSPATH . WPINC . '/option.php'; 
} 

class Hubhopper_Player_Plugin_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Hubhopper_Player_Plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Hubhopper_Player_Plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/hubhopper-player-plugin-admin.css', array(), $this->version, 'all' );
		wp_register_style( 'jquery-ui-styles','https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.24/themes/base/jquery-ui.css' );
		wp_enqueue_style( 'jquery-ui-styles' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Hubhopper_Player_Plugin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Hubhopper_Player_Plugin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/hubhopper-player-plugin-admin.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( 'jquery-ui-autocomplete' );

	}

	public function hh_plugin_setup_menu(){
	    add_menu_page( 'HH Player Settings', 'HH Player Admin', 'manage_options', 'hh-player-settings', array($this, 'hh_plugin_setting_display'), 'dashicons-playlist-audio', 6 );
	}

	public function hh_plugin_setting_display() {
		$success = false;
		$filename = basename(__FILE__);
		if (!current_user_can('manage_options')) {
	        wp_die('Unauthorized user');
	    }

	    if (! empty($_POST['hh_player_wnonce']) && wp_verify_nonce( $_POST['hh_player_wnonce'], $filename ) && isset($_POST['data']) ) {
	        $success = true;
	        //print_r($_POST['containerId']);
	        $data = array('apiKey' => $_POST['apiKey'], 'containerId' => $_POST['containerId'], 'podcast' => (int) $_POST['podcast'], 'podcastDisplay' => $_POST['podcastDisplay'], 'similar' => array_map("intval", explode(",", $_POST['similar'])), 'similarDisplay' => $_POST['similarDisplay'], 'externalizeSimilar' => $_POST['externalizeSimilar'] === 'true' ? true : false, 'showSimilar' => $_POST['showSimilar'] === 'true' ? true : false, 'autoPlay' => $_POST['autoPlay'] === 'true' ? true : false, 'widget' => $_POST['widget'] === 'true' ? true : false);
	        
	        $result = update_option('hh_player_setting_option', json_encode($data));
			
			unset($data['podcastDisplay']);
			unset($data['similarDisplay']);

			$data['containerId'] = '#' . $data['containerId'];
			
			if($result){
		        if(! get_option('hh_player_options')) {
		        	add_option('hh_player_options', json_encode($data));
		        } else {
					update_option('hh_player_options', json_encode($data));
		        }
	    	}
	    }

	    $opts = json_decode(get_option('hh_player_setting_option'), true);
		//print_r(json_encode($opts));
		include( plugin_dir_path( dirname( __FILE__ ) ) . '/admin/partials/hubhopper-player-plugin-admin-display.php' );
	}

	public function hh_plugin_setup_options() {
		$opts = array('apiKey' => '', 'containerId' => 'hhPlayer', 'podcast' => 0, 'podcastDisplay' => '', 'similar' => array(0,0,0,0), 'similarDisplay' => '', 'externalizeSimilar' => false, 'showSimilar' => true, 'autoPlay' => false, 'widget' => false);
		if(! get_option('hh_player_setting_option'))
			add_option('hh_player_setting_option', json_encode($opts));
	}

	

}
